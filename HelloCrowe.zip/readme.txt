http://localhost:63988/Home/Index

Button makes a call to the api, that return the string "Hello World" and adds that onto the screen.