﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace HelloCrowe.Controllers
{
    public class HelloController : ApiController
    {
        public string Get()
        {
            return "Hello World";
        }
        public List<string> Get(int Id)
        {
            return new List<string> {
                "Hello",
                "World"
            };
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");
        }
    }
}
